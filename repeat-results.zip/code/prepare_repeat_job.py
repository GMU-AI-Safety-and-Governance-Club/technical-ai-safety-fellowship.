"""Package the fixed repeat job; resulting script has no account keys or classroom codes."""
import ast
import base64
import gzip
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "shared-qwen-class"
files = {name: (BASE / name).read_text(encoding="utf-8") for name in ["project.py", "classroom.py", "config.json",
          "data/plan.jsonl", "data/smoke-plan.jsonl", "data/questions.jsonl", "data/provenance.json"]}
files["run_repeat.py"] = (ROOT / "run_repeat.py").read_text(encoding="utf-8")
files["original-summary.json"] = (ROOT / "recovered/saved-class-summary.json").read_text()
files["known-original-replies.jsonl"] = (ROOT / "recovered/printed-slot-1-responses.jsonl").read_text()
payload = base64.b64encode(gzip.compress(json.dumps(files).encode())).decode()
script = '''# /// script
# requires-python = ">=3.11,<3.13"
# dependencies = ["torch==2.8.0", "transformers==4.57.1", "accelerate==1.10.1", "bitsandbytes==0.48.1", "numpy==2.2.6", "matplotlib==3.10.7", "huggingface_hub==0.36.2"]
# ///
import base64, gzip, hashlib, json, os, sys
from pathlib import Path
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
''' + "FILES = json.loads(gzip.decompress(base64.b64decode(" + repr(payload) + ")))\n" + '''root = Path("/tmp/qwen-repeat-code")
root.mkdir(parents=True, exist_ok=True)
for name, text in FILES.items():
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
sys.path.insert(0, str(root))
import torch
torch.set_num_threads(4)
try:
    from run_repeat import main
    main()
finally:
    output = Path("/tmp/qwen-repeat-2026-11-12")
    archive = {str(p.relative_to(output)): base64.b64encode(p.read_bytes()).decode("ascii")
               for p in output.rglob("*") if p.is_file()}
    packed = gzip.compress(json.dumps(archive).encode())
    encoded = base64.b64encode(packed).decode()
    print("ARTIFACT_SHA256", hashlib.sha256(packed).hexdigest(), flush=True)
    for start in range(0, len(encoded), 4000):
        print("ARTIFACT_CHUNK", start//4000, encoded[start:start+4000], flush=True)
    print("ARTIFACT_END", len(encoded), flush=True)
'''
ast.parse(script)
(ROOT / "remote_repeat.py").write_text(script, encoding="utf-8")
print(json.dumps({"script": script}))
