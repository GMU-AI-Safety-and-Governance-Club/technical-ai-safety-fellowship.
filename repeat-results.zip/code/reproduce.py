"""Recompute saved results using CPU only: python code/reproduce.py. No model calls."""
import json
from pathlib import Path

from project import read_jsonl, analyze
from analysis_tools import merge_and_check

root = Path(__file__).resolve().parent.parent
records = read_jsonl(root / "combined/responses.jsonl")
plan = read_jsonl(root / "combined/plan.jsonl")
provenance = json.loads((root / "provenance.json").read_text())
summary = analyze(records, plan, root / "reproduced/analysis")
reviews = root / "received-reviews"
if not list(reviews.glob("*.csv")):
    reviews = root / "my-reviews"
if not list(reviews.glob("*.csv")):
    reviews = root / "combined/reviews-final"
state = merge_and_check(reviews, records, plan, provenance["audit_ids"], root / "reproduced/review")
print(json.dumps({"requests": summary["recorded_requests"], "complete_triples": summary["complete_parsed_triples"],
                  "primary_delta_probability_a": summary["primary_delta_probability_a"],
                  "review_complete": state["review_complete"], "note": "CPU recomputation only; no new model generation."}, indent=2))
