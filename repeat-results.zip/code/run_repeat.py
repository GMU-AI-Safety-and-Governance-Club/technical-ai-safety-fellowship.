"""One fixed repeat of the baseline. Not a recovery or replacement of the October run."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import secrets
import time

def main():
    from project import QwenBackend, collect, read_jsonl, save_json, save_jsonl, fingerprint, analyze, make_review_files
    from classroom import Classroom, merge_snapshot
    import torch
    root = Path(__file__).resolve().parent
    output = Path("/tmp/qwen-repeat-2026-11-12")
    config = json.loads((root / "config.json").read_text())
    plan = read_jsonl(root / "data/plan.jsonl")
    items = read_jsonl(root / "data/questions.jsonl")
    provenance = json.loads((root / "data/provenance.json").read_text())
    started = time.perf_counter()
    report = {"passed": False, "run_kind": "Independent repeat on November 12; do not pool with October observations",
              "fixed_plan_requests": len(plan), "notes": ["One prespecified attempt per request, no outcome-based retries.",
              "Fresh prompts, same saved model revision/quantization/settings/seeds. Cross-slot timing may differ."]}
    save_json(output / "repeat-report.json", report)
    try:
        backend = QwenBackend(config).load()
        print("MODEL_READY", json.dumps(backend.metadata), flush=True)
        smoke_plan = read_jsonl(root / "data/smoke-plan.jsonl")
        smoke_records = collect(backend, smoke_plan, output / "smoke", max_seconds=600)
        smoke = {"passed": len(smoke_records) == 6 and all(r["parse_status"] == "ok" for r in smoke_records),
                 "model": backend.metadata, "plan_hash": fingerprint(smoke_plan)}
        save_json(output / "smoke-report.json", smoke)
        if not smoke["passed"]: raise RuntimeError("Startup test failed; no baseline collection")
        codes = {i: secrets.token_urlsafe(24) for i in range(1, 11)}
        classroom = Classroom(backend, plan, smoke, output / "collection", codes)
        def collect_part(owner):
            for request in classroom.parts[owner]:
                packet = classroom.next(owner, codes[owner], request["request_id"], True)
                row = next(r for r in packet["records"] if r["request_id"] == request["request_id"])
                if row["request_status"] != "completed" or row["parse_status"] == "truncated":
                    raise RuntimeError("Saved failure/truncation; preserving without a retry")
            return len(packet["records"])
        with ThreadPoolExecutor(max_workers=10) as executor:
            counts = list(executor.map(collect_part, range(1, 11)))
        snapshot = classroom.snapshot(1, codes[1])
        records = merge_snapshot(snapshot, plan, output / "combined")
        summary = analyze(records, plan, output / "combined/analysis")
        make_review_files(records, items, provenance["audit_ids"], output / "combined/reviews-final", groups=5)
        previous = json.loads((root / "original-summary.json").read_text())
        known = read_jsonl(root / "known-original-replies.jsonl")
        current = {r["request_id"]: r for r in records}
        matches = [{"request_id": r["request_id"], "same_answer": r["parsed_answer_recomputed"] == current[r["request_id"]]["parsed_answer"],
                    "same_text": r["raw_response"] == current[r["request_id"]]["raw_response"]} for r in known]
        save_json(output / "original-vs-repeat.json", {"original_summary": previous, "repeat_summary": summary,
                  "known_original_response_comparisons": matches,
                  "matching_answers": sum(r["same_answer"] for r in matches), "matching_texts": sum(r["same_text"] for r in matches),
                  "scope": "Original raw archive missing. Exact original comparison limited to the 24 recovered slot-1 replies."})
        save_json(output / "provenance.json", provenance)
        save_json(output / "model-config.json", config)
        save_jsonl(output / "items.jsonl", items)
        report.update(passed=len(records) == 240 and all(r["parse_status"] == "ok" for r in records),
                      model=backend.metadata, recorded=len(records), by_slot=counts, summary=summary,
                      peak_gpu_bytes=torch.cuda.max_memory_allocated(), elapsed_seconds=time.perf_counter()-started,
                      known_original_answers_matching=sum(r["same_answer"] for r in matches),
                      known_original_texts_matching=sum(r["same_text"] for r in matches))
    except BaseException as error:
        report.update(error=type(error).__name__ + ": " + str(error)[:1500], elapsed_seconds=time.perf_counter()-started)
        raise
    finally:
        save_json(output / "repeat-report.json", report)
        print("REPEAT_REPORT", json.dumps(report), flush=True)

if __name__ == "__main__": main()
