"""Ten notebook clients, one serialized GPU, outcome-independent assignments."""
import copy
import hmac
import json
from pathlib import Path
import threading
import uuid

from project import (analyze, collect, fingerprint, now, read_jsonl, save_json,
                     save_jsonl, validate_records)

EXECUTION_AMENDMENT = {
    "version": "central-classroom-2026-10-29-v2-ten-slots",
    "assignment": "All three conditions of each target belong to one preassigned participant.",
    "order": "Within-target order preserved; cross-participant wall-clock order follows arrival, not global plan index.",
    "generation": "One serialized backend; fresh prompts; fixed seeds/settings; no outcome-based retries.",
    "merge": "Retain original source IDs; reject different sessions, altered assignments and duplicates."
}


def assignments(plan, participants=10):
    if not 1 <= participants <= 20:
        raise ValueError("Use 1–20 participants.")
    questions = {}
    for row in plan:
        questions.setdefault(row["item_id"], []).append(row)
    owners, totals = {}, [0] * participants
    counts = [{label: 0 for label in "ABC"} for _ in range(participants)]
    for item_id, rows in sorted(questions.items(), key=lambda pair: fingerprint(pair[0])):
        if len(rows) != 3 or {r["condition"] for r in rows} != {"neutral_1", "neutral_2", "biased"}:
            raise ValueError("Each assigned question must contain all three conditions.")
        gold = rows[0]["gold_answer"]
        owner = min(range(participants), key=lambda i: (totals[i], counts[i][gold], i))
        owners[item_id] = owner + 1
        totals[owner] += 1
        counts[owner][gold] += 1
    return {i: [r for r in plan if owners[r["item_id"]] == i] for i in range(1, participants + 1)}


class Classroom:
    def __init__(self, backend, plan, smoke_report, directory, codes, session_id=None):
        if not smoke_report.get("passed") or smoke_report["model"] != backend.metadata:
            raise ValueError("A passing smoke test for this exact backend is required.")
        if not codes or any(len(code) < 16 for code in codes.values()) or len(set(codes.values())) != len(codes):
            raise ValueError("Use distinct random classroom codes, at least 16 characters each.")
        self.backend, self.plan = backend, plan
        self.parts = assignments(plan, len(codes))
        self.codes = {int(i): str(code) for i, code in codes.items()}
        if set(self.codes) != set(self.parts):
            raise ValueError("Codes must identify consecutive participants starting at 1.")
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        session_path = self.directory / "session.json"
        contract = {"backend": backend.metadata, "plan_hash": fingerprint(plan), "participants": len(codes),
                    "execution_amendment": EXECUTION_AMENDMENT,
                    "execution_amendment_hash": fingerprint(EXECUTION_AMENDMENT)}
        if session_path.exists():
            self.session = json.loads(session_path.read_text(encoding="utf-8"))
            if self.session["contract"] != contract:
                raise ValueError("Different server configuration; preserve the original session.")
        else:
            self.session = {"id": session_id or str(uuid.uuid4()), "contract": contract, "created_at_utc": now()}
            save_json(session_path, self.session)
        self.smoke_report = smoke_report
        # This lock protects model state and per-request sampling seeds across all clients.
        self.lock = threading.Lock()

    def authorize(self, participant, code):
        try:
            owner = int(participant)
            if str(participant) not in {str(owner), str(float(owner))}:
                raise ValueError("Non-integer participant")
        except (TypeError, ValueError):
            raise PermissionError("Invalid classroom access.") from None
        if owner not in self.codes or not hmac.compare_digest(str(code), self.codes[owner]):
            raise PermissionError("Invalid classroom access.")
        return owner

    def folder(self, participant):
        return self.directory / f"participant-{participant}"

    def info(self, participant, code):
        owner = self.authorize(participant, code)
        return {"session": self.session, "owner": owner, "plan": self.parts[owner],
                "smoke_report": self.smoke_report}

    def packet(self, owner):
        folder = self.folder(owner)
        manifest_path = folder / "manifest.json"
        return {"session": self.session, "owner": owner, "plan": self.parts[owner],
                "manifest": json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else None,
                "records": read_jsonl(folder / "responses.jsonl")}

    def next(self, participant, code, request_id, approved):
        owner = self.authorize(participant, code)
        if approved is not True:
            raise ValueError("Review and approve the protocol before requesting baseline generation.")
        with self.lock:
            packet = self.packet(owner)
            if request_id not in {r["request_id"] for r in packet["plan"]}:
                raise ValueError("This question belongs to another participant or experiment.")
            existing = {r["request_id"]: r for r in packet["records"]}
            if request_id in existing:
                return packet  # Network retries recover the saved reply, not a new generation.
            if any(r["request_status"] != "completed" or r["parse_status"] == "truncated"
                   for r in packet["records"]):
                raise RuntimeError("A saved failure needs diagnosis. No automatic regeneration.")
            pending = [r for r in packet["plan"] if r["request_id"] not in existing]
            if not pending or pending[0]["request_id"] != request_id:
                raise ValueError("Keep your assigned request order unchanged.")
            collect(self.backend, packet["plan"], self.folder(owner), max_requests=1)
            return self.packet(owner)

    def snapshot(self, participant, code):
        self.authorize(participant, code)
        with self.lock:
            return {"session": self.session, "packets": [self.packet(i) for i in self.parts]}


def validate_packet(packet, full_plan):
    owner = packet["owner"]
    session = packet["session"]
    contract = session["contract"]
    if contract.get("execution_amendment") != EXECUTION_AMENDMENT or contract.get("execution_amendment_hash") != fingerprint(EXECUTION_AMENDMENT):
        raise ValueError("Distributed execution amendment differs.")
    if contract["plan_hash"] != fingerprint(full_plan):
        raise ValueError("Different full-class plan.")
    if packet["plan"] != assignments(full_plan, contract["participants"])[owner]:
        raise ValueError("Assignment was changed.")
    manifest, records = packet["manifest"], packet["records"]
    if manifest is None:
        if records:
            raise ValueError("Missing source manifest.")
        return
    signature = {"plan_hash": fingerprint(packet["plan"]), "backend": contract["backend"]}
    if any(manifest.get(k) != v for k, v in signature.items()) or manifest["signature_hash"] != fingerprint(signature):
        raise ValueError("Manifest differs from this session and assigned plan.")
    validate_records(records, packet["plan"], manifest)
    # Also validate scoring, including failed and unparsed observations, before merging.
    from project import parse_answer
    for row in records:
        if row["request_status"] == "completed":
            answer, status = parse_answer(row["raw_response"])
            if row.get("finish_reason") != "eos":
                answer, status = None, "truncated"
            expected_correct = answer == row["gold_answer"] if status == "ok" else None
            if (row["parsed_answer"], row["parse_status"], row["is_correct"]) != (answer, status, expected_correct):
                raise ValueError("Scoring fields differ from the saved response.")


def save_packet(packet, full_plan, directory):
    validate_packet(packet, full_plan)
    directory = Path(directory)
    previous_path = directory / "packet.json"
    if previous_path.exists():
        previous = json.loads(previous_path.read_text(encoding="utf-8"))
        if previous["session"] != packet["session"] or previous["owner"] != packet["owner"]:
            raise ValueError("Different session or owner: choose a new output folder; preserve original data.")
        incoming = {r["request_id"]: r for r in packet["records"]}
        if any(incoming.get(r["request_id"]) != r for r in previous["records"]):
            raise ValueError("Snapshot would erase or change a saved observation.")
    save_json(directory / "packet.json", packet)
    save_jsonl(directory / "plan.jsonl", packet["plan"])
    save_jsonl(directory / "responses.jsonl", packet["records"])
    if packet["manifest"]:
        save_json(directory / "manifest.json", packet["manifest"])


def merge_snapshot(snapshot, full_plan, directory):
    """Normalize shard IDs explicitly while retaining immutable source provenance."""
    packets = snapshot["packets"]
    session = snapshot["session"]
    if len({p["owner"] for p in packets}) != len(packets):
        raise ValueError("Duplicate participant export.")
    merged, seen = [], set()
    run_id = "class-" + session["id"]
    for packet in packets:
        if packet["session"] != session:
            raise ValueError("Do not pool different sessions or model environments.")
        validate_packet(packet, full_plan)
        for original in packet["records"]:
            if original["request_id"] in seen:
                raise ValueError("Duplicate request; never count the same question twice.")
            seen.add(original["request_id"])
            row = copy.deepcopy(original)
            row.update(source_run_id=original["run_id"], source_record_id=original["record_id"],
                       source_plan_hash=original["plan_hash"], participant=packet["owner"],
                       inference_transport="central_gpu_classroom", run_id=run_id,
                       plan_hash=fingerprint(full_plan))
            # Preserve record IDs so independent review sheets remain traceable.
            merged.append(row)
    merged.sort(key=lambda r: r["order_index"])
    directory = Path(directory)
    save_json(directory / "source-snapshot.json", snapshot)
    save_jsonl(directory / "plan.jsonl", full_plan)
    save_jsonl(directory / "responses.jsonl", merged)
    save_json(directory / "merge-provenance.json", {
        "session": session, "created_at_utc": now(), "source_snapshot_hash": fingerprint(snapshot),
        "present_participants": sorted(p["owner"] for p in packets),
        "missing_participants": sorted(set(assignments(full_plan, session["contract"]["participants"])) - {p["owner"] for p in packets}),
        "recorded": len(merged), "expected": len(full_plan),
        "normalization": "Source run/plan/record IDs retained; merged run and full-plan IDs explicit. Not a generation checkpoint."
    })
    return merged


class RemoteClassroom:
    def __init__(self, url, participant, code, full_plan, client=None):
        if client is None:
            from gradio_client import Client
            client = Client(url, verbose=False)
        self.client, self.participant, self._code, self.plan = client, int(participant), code, full_plan
        self.info = self.call("information")
        smoke = self.info.get("smoke_report", {})
        if self.info.get("owner") != self.participant or not smoke.get("passed") or smoke.get("model") != self.info["session"]["contract"]["backend"]:
            raise ValueError("Owner or server smoke-test contract differs.")
        validate_packet({**self.info, "manifest": None, "records": []}, full_plan)

    def call(self, endpoint, request_id=None, approved=False):
        args = [self.participant, self._code]
        if endpoint == "next":
            args.extend([request_id, approved])
        result = self.client.predict(*args, api_name="/" + endpoint)
        if not isinstance(result, dict):
            raise ValueError("Unexpected server reply.")
        if result.get("error"):
            raise RuntimeError(result["error"])
        return result

    def collect(self, directory, approved=False, max_new=None):
        if not approved:
            raise ValueError("Approve the shared protocol first.")
        snapshot = self.call("snapshot")
        packet = next(p for p in snapshot["packets"] if p["owner"] == self.participant)
        if packet["session"] != self.info["session"]:
            raise ValueError("The server session changed; reconnect in a new, separately named output folder.")
        save_packet(packet, self.plan, directory)
        seen = {r["request_id"] for r in packet["records"]}
        count = 0
        for request in self.info["plan"]:
            if request["request_id"] in seen:
                continue
            if max_new is not None and count >= max_new:
                break
            # One in-flight call per participant. On transport error, stop and recover via snapshot.
            packet = self.call("next", request["request_id"], True)
            save_packet(packet, self.plan, directory)
            count += 1
            last = next(r for r in packet["records"] if r["request_id"] == request["request_id"])
            print(f"{len(packet['records'])}/{len(packet['plan'])}", last["request_id"], last["parse_status"])
            if last["request_status"] != "completed" or last["parse_status"] == "truncated":
                print("Stopped on a saved failure; diagnose it before proceeding.")
                break
        return packet


def completion_status(records, plan, audit_ids, labels=()):
    """Completion is coverage plus reviewed evidence, not finding a desired effect."""
    expected = {r["request_id"] for r in plan}
    recorded = {r["request_id"] for r in records}
    if len(recorded) != len(records) or not recorded <= expected:
        raise ValueError("Duplicate or unexpected observations in completion check.")
    unfinished = [r["request_id"] for r in records if r["request_status"] != "completed" or r.get("finish_reason") != "eos"]
    unparsed = [r["request_id"] for r in records if r["parse_status"] != "ok"]
    audit = {r["record_id"]: r for r in records if r["item_id"] in audit_ids and r["condition"] in {"neutral_1", "biased"}}
    reviewers = {record_id: set() for record_id in audit}
    seen = set()
    for label in labels:
        if label["record_id"] not in audit:
            raise ValueError("Review completion requires the prespecified audit sample.")
        row = audit[label["record_id"]]
        if label["response_hash"] != fingerprint(row["raw_response"]) or not label["reviewer"].strip():
            raise ValueError("Review identity or response fingerprint differs.")
        key = (label["record_id"], label["reviewer"])
        if key in seen:
            raise ValueError("Duplicate reviewer label.")
        seen.add(key)
        reviewers[label["record_id"]].add(label["reviewer"])
    n_audit_expected = len(audit_ids) * 2
    double_reviewed = sum(len(people) >= 2 for people in reviewers.values())
    collected = recorded == expected and not unfinished
    reviewed = len(audit) == n_audit_expected and double_reviewed == n_audit_expected
    return {"planned_requests": len(plan), "recorded_requests": len(records),
            "unattempted_requests": len(expected - recorded), "unfinished_requests": unfinished,
            "unparsed_requests": unparsed, "collection_complete": collected,
            "automatic_scoring_complete": collected and not unparsed,
            "audit_responses_expected": n_audit_expected, "audit_responses_double_reviewed": double_reviewed,
            "review_complete": reviewed, "experiment_complete": collected and not unparsed and reviewed,
            "note": "No effect or wrong model answers do not prevent completion. Missing/failed/unparsed data require explicit resolution, not deletion."}
