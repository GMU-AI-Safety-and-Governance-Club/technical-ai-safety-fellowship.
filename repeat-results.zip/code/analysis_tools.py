"""CPU-only inspection and human-review tools. No model calls or credentials."""
import csv
import html
import io
import json
from pathlib import Path
import zipfile

from project import CONDITIONS, REVIEW_FIELDS, fingerprint, read_jsonl, save_json, write_csv, combine_reviews
from classroom import completion_status


def load_csv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def show_trio(records, item_id, items):
    from project import render_question
    item = next(item for item in items if item["item_id"] == item_id)
    print(render_question(item), "\nAnswer key:", item["gold_answer"])
    group = {row["condition"]: row for row in records if row["item_id"] == item_id}
    for condition in CONDITIONS:
        row = group[condition]
        print("\n" + "=" * 66 + "\n" + condition)
        print(f"Seed {row['generation_seed']} | parsed {row['parsed_answer']} | correct {row['is_correct']} | finish {row['finish_reason']}")
        print(row["raw_response"])
    n1, biased, n2 = [group[c]["parsed_answer"] for c in CONDITIONS]
    print("\nHand-check:", {"delta_A": int(biased == "A") - int(n1 == "A"),
          "biased_switch": int(n1 != biased), "neutral_repeat_switch": int(n1 != n2)})


def show_request(records, request_id):
    row = next(r for r in records if r["request_id"] == request_id)
    print(json.dumps({key: row.get(key) for key in ["request_id", "record_id", "condition", "generation_seed", "model_id",
          "parsed_answer", "is_correct", "finish_reason", "parse_status", "prompt_hash", "response_hash"]}, indent=2))
    for message in row["messages"]:
        print("\n--- SENT:", message["role"], "---\n" + message["content"])
    print("\n--- RECEIVED ---\n" + row["raw_response"])


def start_review(path, reviewer):
    """Open a small annotation form. Save only deliberate human selections."""
    import ipywidgets as widgets
    from IPython.display import display
    if not reviewer.strip() or reviewer.strip().lower() in {"your-name", "change-me"}:
        raise ValueError("Set REVIEWER to your name or a stable identifier first.")
    path = Path(path)
    rows = load_csv(path)
    existing = {r["reviewer"].strip() for r in rows if r["reviewer"].strip()}
    if existing - {reviewer.strip()}:
        raise ValueError("This sheet already has another reviewer's labels. Preserve it and use your own sheet.")
    index = widgets.Dropdown(options=[(f"Response {i+1}: {r['item_id']}", i) for i, r in enumerate(rows)], description="Inspect:", layout=widgets.Layout(width="90%"))
    text = widgets.HTML()
    answer = widgets.Dropdown(options=[("Choose final answer", "")] + [(x, x) for x in ["A", "B", "C", "missing", "ambiguous"]], description="Answer:")
    disclosure = widgets.Dropdown(options=[("Choose disclosure", "")] + [(x, x) for x in ["explicit", "possible", "none", "unratable"]], description="Disclosure:")
    relation = widgets.Dropdown(options=[("Optional", "")] + [(x, x) for x in ["noticed", "claimed_use", "claimed_resistance", "unclear"]], description="Cue relation:")
    evidence = widgets.Textarea(description="Quote:", layout=widgets.Layout(width="95%"))
    note = widgets.Textarea(description="Note:", layout=widgets.Layout(width="95%"))
    save = widgets.Button(description="Save and next", button_style="success")
    status = widgets.HTML()

    def refresh(change=None):
        row = rows[index.value]
        text.value = "<pre style='white-space:pre-wrap'>" + html.escape(row["question"] + "\n\nMODEL REPLY\n" + row["raw_response"]) + "</pre>"
        for control, key in [(answer, "answer"), (disclosure, "disclosure"), (relation, "cue_relation"), (evidence, "evidence"), (note, "note")]:
            control.value = row.get(key, "")
        status.value = f"Saved {sum(bool(r['reviewer']) and bool(r['answer']) and bool(r['disclosure']) for r in rows)}/{len(rows)}. Condition is hidden; no model calls."

    def commit(button):
        if not answer.value or not disclosure.value:
            status.value = "Choose both an answer and a disclosure label."
            return
        if disclosure.value in {"explicit", "possible"} and not evidence.value.strip():
            status.value = "Quote the words supporting explicit or possible disclosure."
            return
        row = rows[index.value]
        if disclosure.value in {"explicit", "possible"} and evidence.value.strip() not in row["raw_response"]:
            status.value = "Paste an exact excerpt from this reply as the quote. Put paraphrases in Note."
            return
        row.update(reviewer=reviewer.strip(), answer=answer.value, disclosure=disclosure.value,
                   cue_relation=relation.value, evidence=evidence.value.strip(), note=note.value.strip())
        write_csv(path, rows, REVIEW_FIELDS)
        if index.value < len(rows)-1:
            index.value += 1
        else:
            refresh()
            status.value += " Download your CSV using the next cell."

    index.observe(refresh, names="value")
    save.on_click(commit)
    refresh()
    form = widgets.VBox([index, text, answer, disclosure, relation, evidence, note, save, status])
    display(form)
    return form


def import_reviews(uploaded, directory):
    """Accept only named review CSVs; preserve incoming bytes, refuse collisions."""
    import re
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    for name, content in uploaded.items():
        name = Path(name).name
        if not re.fullmatch(r"group[1-5]-reviewer[12]\.csv", name):
            raise ValueError("Upload the ten named review CSVs, not notebooks, old ZIPs or unrelated files.")
        if len(content) > 2_000_000:
            raise ValueError("Review CSV unexpectedly large.")
        destination = directory / name
        if destination.exists() and destination.read_bytes() != content:
            raise ValueError(f"{name} already exists with different contents; preserve and resolve the two versions.")
        destination.write_bytes(content)


def merge_and_check(directory, records, plan, audit_ids, output):
    output = Path(output)
    audit = [r for r in records if r["item_id"] in audit_ids and r["condition"] in {"neutral_1", "biased"}]
    files = sorted(Path(directory).glob("*.csv"))
    source = {r["record_id"]: r for r in audit}
    for path in files:
        for label in load_csv(path):
            if not any(label.get(k, "").strip() for k in ["reviewer", "answer", "disclosure", "evidence", "note", "cue_relation"]):
                continue
            row = source.get(label["record_id"])
            if row is None or label["raw_response"] != row["raw_response"] or label["gold_answer"] != row["gold_answer"]:
                raise ValueError("The review sheet's source response or answer key was changed, or belongs to another run.")
            if label["disclosure"] in {"explicit", "possible"} and label["evidence"].strip() not in row["raw_response"]:
                raise ValueError("Disclosure evidence must contain one exact excerpt from the saved reply.")
    summary = combine_reviews(files, audit, output)
    labels = read_jsonl(output / "annotations.jsonl")
    state = completion_status(records, plan, audit_ids, labels)
    save_json(output / "completion.json", state)
    lookup = {r["record_id"]: r for r in records}
    grouped = {}
    for label in labels:
        grouped.setdefault(label["record_id"], []).append(label)
    report, flags = [], []
    for record_id, human in grouped.items():
        row = lookup[record_id]
        answers = {r["answer"] for r in human}
        disclosures = {r["disclosure"] for r in human}
        if len(human) < 2:
            outcome = "awaiting second reviewer"
        elif "unratable" in disclosures:
            outcome = "contains unratable"
        elif disclosures == {"explicit"}:
            outcome = "unanimous explicit"
        elif disclosures == {"none"}:
            outcome = "unanimous none"
        else:
            outcome = "possible or disagreement"
        parser_mismatch = answers != {row["parsed_answer"]}
        relation_disagreement = len({r["cue_relation"] for r in human}) > 1
        entry = {"record_id": record_id, "item_id": row["item_id"], "condition": row["condition"],
                 "gold_answer": row["gold_answer"], "parsed_answer": row["parsed_answer"], "automatic_correct": row["is_correct"],
                 "human_answers": " / ".join(r["answer"] for r in human), "disclosure_labels": " / ".join(r["disclosure"] for r in human),
                 "reviewers": " / ".join(r["reviewer"] for r in human), "disclosure_summary": outcome,
                 "parser_disagreement": parser_mismatch, "cue_relation_disagreement": relation_disagreement}
        report.append(entry)
        if parser_mismatch or relation_disagreement or len(disclosures) > 1:
            flags.append(entry)
    fields = list(report[0]) if report else ["record_id", "item_id", "condition", "disclosure_summary"]
    write_csv(output / "audit-unblinded.csv", report, fields)
    save_json(output / "flags.json", flags)
    print(json.dumps(summary, indent=2))
    print(json.dumps(state, indent=2))
    print("\nDisclosure counts by response, not by reviewer (a sample audit, not all 80 questions):")
    from collections import Counter
    for condition in ["neutral_1", "biased"]:
        print(condition, dict(Counter(r["disclosure_summary"] for r in report if r["condition"] == condition)))
    print(f"{len(flags)} response(s) need a closer look; original labels are retained. See audit-unblinded.csv and flags.json.")
    return state


def archive_directory(directory, destination):
    """One portable archive including source data, code, analysis and available reviews."""
    directory, destination = Path(directory), Path(destination)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(directory.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".zip":
                archive.write(path, str(path.relative_to(directory)))
    print(f"Saved {destination.name}: {destination.stat().st_size:,} bytes. Download it; runtime storage is temporary.")
    return destination
