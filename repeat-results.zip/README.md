# Verified repeat execution — November 12, 2026

The Qwen run finished: **240/240 requests, 80 complete parsed triples, all ten slots with 24 replies**. All final answers parsed; no failed or truncated requests. The six held-out startup-test replies are stored separately and excluded from these counts. Human audit labels remain unfinished until completed in the results notebook.

- neutral_1: 66/80 correct (82.5%).
- biased: 62/80 correct (77.5%).
- neutral_2: 58/80 correct (72.5%).

- Biased answer changes: 14/80.
- Neutral-repeat answer changes: 11/80.
- Primary net shift toward A: +3.75 percentage points; exploratory 95% paired-bootstrap interval [-1.25, +10.00].
- Excess answer-change rate over repeated neutral: +3.75 percentage points; exploratory 95% paired-bootstrap interval [-3.75, +12.50].
- Switches toward A: 4/53 questions whose neutral-1 answer was not already A.

The saved October summary was 14/80 biased changes, 11/80 neutral-repeat changes and a +3.75 pp net A shift. Among the 24 recoverable original slot-1 replies, 24/24 final letters and 24/24 exact recovered reply texts match the repeat. Response-level comparison with the remaining 216 original replies is unavailable. This is a repeat of the same fixed sample and seeds, not 80 new independent questions. Keep the executions separate.

Model: Qwen/Qwen2.5-7B-Instruct, pinned revision `a09a35458c702b33eeacc393d103063234e8bc28`. Tesla T4, NF4 double quantization with float16, SDPA attention, temperature 0.7, top-p 1, top-k 0, maximum 512 generated tokens, batch size 1. Generation dependencies and metadata are archived.

Measured script elapsed time: 13.2 minutes (includes loading, startup test, collection, analysis and archival preparation, excludes some job startup time). GPU job: `6af6270e5f2f1b7284b8c02b`. Requested hard timeout: 60 minutes. Published T4-small rate at launch: $0.40/hour, so the requested hardware-time ceiling is $0.40; actual account billing has not been inspected. No subscription or persistent server was created. [Hugging Face Jobs pricing](https://huggingface.co/docs/hub/jobs-pricing).

## What to use

Give everyone `ready-to-share/results-review.ipynb`. It embeds the complete saved repeat data and CPU analysis code. Default execution makes no model calls. It also includes an optional, explicitly enabled section for new generation in a separate compatible GPU environment. Use `instructor-notes.md` for the guided two-hour meeting. The raw data backup is `ready-to-share/repeat-results.zip`; no access codes or account secrets are included.

The experiment's collection and automatic scoring are finished. Finish the independent 24-text, 48-label human audit during the meeting, investigate cases, record bounded conclusions and download the final notebook plus ZIP. A weak or null effect is a valid outcome; absence of cue disclosure is not evidence of intentional deception.

To reproduce calculations from this raw archive outside a notebook: install NumPy and Matplotlib, unzip it, and run `python code/reproduce.py`. It never downloads a model or makes model calls. It uses completed review CSVs if present and otherwise correctly reports the audit as unfinished. The original generation dependencies are in `code/requirements-generation.txt`; they are not required for CPU analysis.
